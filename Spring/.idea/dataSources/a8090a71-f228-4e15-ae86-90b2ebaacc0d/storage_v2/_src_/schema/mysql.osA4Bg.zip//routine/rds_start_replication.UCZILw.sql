create
    definer = rdsadmin@localhost procedure rds_start_replication()
BEGIN
DECLARE v_mysql_version VARCHAR(20);
DECLARE v_threads_running INT;
DECLARE v_called_by_user VARCHAR(50);
DECLARE v_sleep int;
DECLARE sql_logging BOOLEAN;
select @@sql_log_bin into sql_logging;
Select user() into v_called_by_user;
Select version() into v_mysql_version;
SELECT COUNT(1) into v_threads_running FROM information_schema.processlist WHERE user = 'system user';
   if v_threads_running = 0
      then
       set @@sql_log_bin=off;
       update mysql.rds_replication_status set called_by_user=v_called_by_user,action='start slave', mysql_version=v_mysql_version where action is not null;
       commit;
       select sleep(1) into v_sleep;
      START SLAVE;
      SELECT COUNT(1) into v_threads_running FROM information_schema.processlist WHERE user = 'system user';
           if v_threads_running = 2 
           then 
           insert into mysql.rds_history (called_by_user,action,mysql_version) values (v_called_by_user,'start slave', v_mysql_version);
           commit;
           Select 'Slave running normally.' as Message;
           else 
           Select 'Slave has encountered an error. Run SHOW SLAVE STATUS\\G; to see the error.' as Message;
           end if;
      else
      if v_threads_running = 2
      then
      Select 'Slave may already running. Call rds_stop_replication to stop replication;' as Message;   
      end if;
  end if;
set @@sql_log_bin=sql_logging;
END;

