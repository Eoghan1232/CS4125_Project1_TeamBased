create definer = rdsadmin@localhost event ev_rds_gsh_collector on schedule
    every '5' MINUTE
        starts '2020-07-26 11:06:22'
    on completion preserve
    disable
    do
    CALL rds_collect_global_status_history();

